***
#Prática Laboratorial 2 CBD 2019/2020
###João Laranjo 91153
***
##2.1 MongoDB – Instalação e exploração por linha de comandos
[MongoDB](https://www.mongodb.com/)

[Installing MongoDB on MACOS](https://docs.mongodb.com/manual/tutorial/install-mongodb-on-os-x/)

Instalação com Brew

```
brew install mongodb-community@4.2
```

```
brew services start mongodb-community@4.2
```

MongoDB shell version v4.2.1
git version: edf6d45851c0b9ee15548f0f847df141764a317e
allocator: system
modules: none
build environment:
    distarch: x86_64
    target_arch: x86_64
