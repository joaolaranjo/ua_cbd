Exercicio 1_2
SET INICIAL NUMERO
	1_2.py
	Ficheiro Criado: set_initial_number.txt
	Ficheiro do tipo:
	"SET A 463 \n
	"SET B 257 \n 
	(...)"

Carregado para o redis através do terminal:
cat set_initial_number.txt | redis-cli --pipe

All data transferred. Waiting for the last reply...
Last reply received from server.
errors: 0, replies: 26